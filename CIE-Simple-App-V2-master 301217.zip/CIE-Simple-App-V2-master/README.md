# CIE-Simple-App-V2
CIE Simple App V2
Sample Android Application using CIE Android SDK V2 to connect to CIE Bluetooth Thermal Printer.

This application shows how to print
* Image
* Text with basic formatting
* Barcode
* QR Code
* Unicode Text Printing
